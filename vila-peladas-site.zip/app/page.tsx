"use client";
import React, { useEffect } from "react";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Instagram } from "lucide-react";

export default function VilaPeladasHome() {
  useEffect(() => {
    console.log("Componente VilaPeladasHome foi montado");
  }, []);

  console.log("Renderizando componente VilaPeladasHome");

  return (
    <main className="min-h-screen bg-gradient-to-br from-white to-gray-100 text-gray-800 p-4">
      <header className="text-center py-10">
        <div className="flex justify-center mb-4">
          <Image
            src="/IMG_5244.JPG"
            alt="Logo Peladas 24 Horas"
            width={120}
            height={120}
            className="rounded"
          />
        </div>
        <h1 className="text-4xl font-bold mb-2">Vila Peladas</h1>
        <p className="text-lg">Informações e novidades da comunidade de Vila Peladas, Caruaru - PE</p>
        <div className="mt-4 flex justify-center">
          <a
            href="https://www.instagram.com/peladas24horas?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-blue-600 hover:underline"
          >
            <Instagram />
            Siga no Instagram
          </a>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          📍 Localização: Vila Peladas, Caruaru - PE
        </div>
      </header>

      <section className="max-w-4xl mx-auto my-12">
        <h2 className="text-2xl font-bold mb-4 text-center">Vista Panorâmica da Vila</h2>
        <div className="rounded overflow-hidden shadow-lg">
          <Image
            src="/IMG_0939.JPG"
            alt="Vista da Vila Peladas a partir da Pedra do Cruzeiro"
            width={1200}
            height={800}
            className="w-full h-auto object-cover"
          />
          <div className="p-4">
            <p className="text-md text-gray-700">
              Uma belíssima visão da Vila Peladas vista do alto da Pedra do Cruzeiro, um dos pontos mais altos e marcantes da região. Um local perfeito para apreciar a paisagem e refletir sobre a história da comunidade.
            </p>
          </div>
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-2">Sobre Vila Peladas</h2>
            <p>
              Vila Peladas é uma comunidade localizada em Caruaru, Pernambuco, rica em história e cultura.
              Aqui você encontrará informações sobre suas origens, marcos importantes e curiosidades locais.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-2">Notícias e Eventos</h2>
            <p>
              Acompanhe as últimas novidades, eventos comunitários, melhorias na vila e muito mais.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-2">Contato</h2>
            <p>
              Entre em contato com a equipe responsável pelo site para dúvidas, sugestões ou envio de conteúdo.
            </p>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center mt-16 text-sm text-gray-500">
        &copy; {new Date().getFullYear()} Vila Peladas. Todos os direitos reservados.
      </footer>
    </main>
  );
}
